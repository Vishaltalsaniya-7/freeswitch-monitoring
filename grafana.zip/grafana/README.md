# VoIP Monitoring Stack

A Docker-based monitoring and observability stack for FreeSWITCH and VoIP infrastructure using **Prometheus**, **Grafana**, **Loki**, **HOMER**, **Heplify Server**, **Node Exporter**, and **FreeSWITCH Exporter**.

## Prerequisites

* Docker
* Docker Compose

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/yourusername/voip-monitoring-stack.git
cd voip-monitoring-stack
```

### 2. Configure environment variables

Copy the example environment file and update it with your credentials.

```bash
cp .env.example .env
```

Edit the `.env` file and configure values such as:

* FreeSWITCH ESL Host
* FreeSWITCH ESL Password
* MySQL/PostgreSQL Credentials
* Grafana Admin Username & Password
* HOMER Database Credentials

### 3. Start the monitoring stack

```bash
docker compose up -d
```

## Access Services

| Service      | URL                   |
| ------------ | --------------------- |
| HOMER        | http://localhost:9080 |
| Grafana      | http://localhost:9030 |
| Prometheus   | http://localhost:9090 |
| Alertmanager | http://localhost:9093 |
| Loki         | http://localhost:3100 |

## Features

* FreeSWITCH monitoring using FreeSWITCH Exporter
* Linux server monitoring with Node Exporter
* SIP capture and call analysis with HOMER
* Heplify Server integration
* Centralized logging with Loki
* Prometheus metrics collection
* Grafana dashboards
* Docker Compose deployment
* Easy configuration using environment variables

## Updating Configuration

After modifying Prometheus or Alertmanager configuration, reload without restarting containers.

### Reload Prometheus

```bash
curl -X POST http://localhost:9090/-/reload
```

### Reload Alertmanager

```bash
curl -X POST http://localhost:9093/-/reload
```

## Restart Services

```bash
docker compose up -d
```

## Stop the Stack

```bash
docker compose down
```
